#/bin/bash
DIR=$1
var1=$(ls $DIR/*.txt | cut -c 10-31)
echo $var1
for arq in $(find $DIR -maxdepth 1 | grep "NO" | grep ".txt" );
do
	echo $arq
	var2=$(echo $arq | cut -c 10-29)COMPLETO.mp4
	ffmpeg -f concat -safe 0 -i $arq -c copy $var2	
done	
